<?php
// Configuración de la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "evento_registro";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Operaciones CRUD
if (isset($_POST['action'])) {
    $action = $_POST['action'];

    if ($action == 'create') {
        $title = $_POST['title'];
        $description = $_POST['description'];
        $image = $_POST['image'];
        $time = $_POST['time'];
        $category = $_POST['category'];

        $sql = "INSERT INTO report_blog (title, description, image, time, category) VALUES ('$title', '$description', '$image', '$time', '$category')";
        $conn->query($sql);
    } elseif ($action == 'update') {
        $id = $_POST['id'];
        $title = $_POST['title'];
        $description = $_POST['description'];
        $image = $_POST['image'];
        $time = $_POST['time'];
        $category = $_POST['category'];

        $sql = "UPDATE report_blog SET title='$title', description='$description', image='$image', time='$time', category='$category' WHERE id=$id";
        $conn->query($sql);
    } elseif ($action == 'delete') {
        $id = $_POST['id'];
        $sql = "DELETE FROM report_blog WHERE id=$id";
        $conn->query($sql);
    }
}

// Obtener los datos
$sql = "SELECT * FROM report_blog";
$result = $conn->query($sql);

$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD de Reportajes</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap">
    <link rel="stylesheet" href="assets/css/styles.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
</head>
<body>
    <div class="container mt-4">
        <h1 class="mb-4">CRUD de Reportajes</h1>

        <!-- Formulario de Creación/Edición -->
        <form id="crudForm" method="post" action="crud.php">
            <input type="hidden" name="action" id="formAction" value="create">
            <input type="hidden" name="id" id="reportId">
            <div class="form-group">
                <label for="title">Título</label>
                <input type="text" class="form-control" id="title" name="title" required>
            </div>
            <div class="form-group">
                <label for="description">Descripción</label>
                <textarea class="form-control" id="description" name="description" rows="3" required></textarea>
            </div>
            <div class="form-group">
                <label for="image">URL de la Imagen</label>
                <input type="text" class="form-control" id="image" name="image" required>
            </div>
            <div class="form-group">
                <label for="time">Tiempo</label>
                <input type="text" class="form-control" id="time" name="time" required>
            </div>
            <div class="form-group">
                <label for="category">Categoría</label>
                <input type="text" class="form-control" id="category" name="category" required>
            </div>
            <button type="submit" class="btn btn-primary">Guardar</button>
        </form>

        <!-- Tabla de Datos -->
        <table class="table table-striped mt-4">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Título</th>
                    <th>Descripción</th>
                    <th>Imagen</th>
                    <th>Tiempo</th>
                    <th>Categoría</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo $row['title']; ?></td>
                        <td><?php echo $row['description']; ?></td>
                        <td><img src="<?php echo $row['image']; ?>" class="img-fluid" width="100"></td>
                        <td><?php echo $row['time']; ?></td>
                        <td><?php echo $row['category']; ?></td>
                        <td>
                            <button class="btn btn-warning btn-sm" onclick="editReport(<?php echo $row['id']; ?>, '<?php echo $row['title']; ?>', '<?php echo $row['description']; ?>', '<?php echo $row['image']; ?>', '<?php echo $row['time']; ?>', '<?php echo $row['category']; ?>')">Editar</button>
                            <button class="btn btn-danger btn-sm" onclick="deleteReport(<?php echo $row['id']; ?>)">Eliminar</button>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <script>
        function editReport(id, title, description, image, time, category) {
            document.getElementById('formAction').value = 'update';
            document.getElementById('reportId').value = id;
            document.getElementById('title').value = title;
            document.getElementById('description').value = description;
            document.getElementById('image').value = image;
            document.getElementById('time').value = time;
            document.getElementById('category').value = category;
        }

        function deleteReport(id) {
            Swal.fire({
                title: '¿Estás seguro?',
                text: "No podrás revertir esto.",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Sí, eliminarlo.'
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById('formAction').value = 'delete';
                    document.getElementById('reportId').value = id;
                    document.getElementById('crudForm').submit();
                }
            })
        }
    </script>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
