<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reportaje</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
    <div class="container mt-4">
        <button class="btn btn-danger mb-3" onclick="window.close();">X</button>
        <div class="report">
            <div class="row">
                <div class="col-md-12">
                    <h1>Medias Rojas se sobreponen a HR de Judge con rally de 3 carreras en el 8vo y vencen 9-7 a Yankees</h1>
                    <small class="text-muted">Historia de AP • 11h • 2 minutos de lectura</small>
                    <img src="assets/img/reportaje/1.png" class="img-fluid rounded mt-3" alt="Reportaje">
                </div>
                <div class="col-md-12 mt-3">
                    <p>BOSTON (AP) — Masataka Yoshida sonó un sencillo...</p>
                    <!-- Continúa el contenido del reportaje aquí -->
                </div>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
