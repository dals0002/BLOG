<header>
    <h1>Blog de Venezolanos en Sajonia e.V</h1>
    <nav>
        <ul>
            <li><a href="#">Inicio</a></li>
            <li><a href="#">Categorías</a></li>
            <li><a href="#">Sobre Nosotros</a></li>
            <li><a href="#">Contacto</a></li>
        </ul>
    </nav>
</header>
