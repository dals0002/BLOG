<footer>
    <nav class="footer-menu">
        <ul>
            <li><a href="#">◉ Inicio</a></li>
            <li><a href="#">◉ Categorías</a></li>
            <li><a href="#">◉ Sobre Nosotros</a></li>
            <li><a href="#">◉ Contacto</a></li>
        </ul>
    </nav>
    <p>&copy; <span id="start-year">2024</span> - <span id="current-year"></span> Blog de Venezolanos en Sajonia e.V. Todos los derechos reservados. <br>Desarrollado por  <a href="https://daniel.itsupportdeu.com/" target="_blank" class="footer-link">Daniel Lugo</a>.</p>
</footer>
